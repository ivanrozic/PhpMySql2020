Za pravilno kori�tenje aplikacije potrebno je:
1. Stvoriti bazu imena "contacts"
2. pokrenuti skriptu users.sql na novokreiranoj bazi
2. pokrenuti skriptu persons and contacts.sql na novokreiranoj bazi